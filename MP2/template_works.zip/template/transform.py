
# transform.py
# ---------------
# Licensing Information:  You are free to use or extend this projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to the University of Illinois at Urbana-Champaign
# 
# Created by Jongdeog Lee (jlee700@illinois.edu) on 09/12/2018

"""
This file contains the transform function that converts the robot arm map
to the maze.
"""
import copy
from arm import Arm
from maze import Maze
from search import *
from geometry import *
from const import *
from util import *

def transformToMaze(arm, goals, obstacles, window, granularity):
    """This function transforms the given 2D map to the maze in MP1.
    
        Args:
            arm (Arm): arm instance
            goals (list): [(x, y, r)] of goals
            obstacles (list): [(x, y, r)] of obstacles
            window (tuple): (width, height) of the window
            granularity (int): unit of increasing/decreasing degree for angles

        Return:
            Maze: the maze instance generated based on input arguments.

    """
    limits = Arm.getArmLimit(arm)
    alpha_lims = limits[0]
    beta_lims = limits[1]
    alpha = int((alpha_lims[1] - alpha_lims[0])/granularity) + 1
    beta = int((beta_lims[1] - beta_lims[0])/granularity) + 1
    start = Arm.getArmAngle(arm)
    startIdx = angleToIdx([start[0],start[1]],[alpha_lims[0],beta_lims[0]],granularity)
    print(startIdx)
    map = []
    for a in range(alpha):
        beta_row = []
        for b in range(beta):
            beta_row.append(SPACE_CHAR)
        map.append(beta_row)
    for a in range(alpha_lims[0],alpha_lims[1] + granularity, granularity):
        for b in range(beta_lims[0],beta_lims[1] + granularity, granularity):
            Arm.setArmAngle(arm,(a,b))
            armPos = Arm.getArmPos(arm)
            armEnd = Arm.getEnd(arm)
            armPosDist = Arm.getArmPosDist(arm)
            index = angleToIdx([a,b],[alpha_lims[0],beta_lims[0]],granularity)
            if index[0] is startIdx[0] and index[1] is startIdx[1]:
                map[index[0]][index[1]] = START_CHAR #
            elif not isArmWithinWindow(armPos, window) or doesArmTouchObjects(armPosDist,obstacles, False):
                map[index[0]][index[1]] = WALL_CHAR
            elif doesArmTouchObjects(armPosDist, goals, True) and not doesArmTipTouchGoals(armEnd, goals):  # goals works fine, just need to add more walls
                map[index[0]][index[1]]  = WALL_CHAR
            elif doesArmTouchObjects(armPosDist, goals, True) and doesArmTipTouchGoals(armEnd, goals):
                map[index[0]][index[1]] = OBJECTIVE_CHAR
    return Maze(map,[alpha_lims[0],beta_lims[0]],granularity)